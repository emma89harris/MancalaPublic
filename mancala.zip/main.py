import pyodbc
from tkinter import *

from Board import Board
from Player import Player
from GUI import GUI

if __name__ == "__main__":

    ##########################################
    ########## FOR USER TO COMPLETE ##########
    ##########################################

    #### DEFAULT BOARD CONFIG ####
    # This can be changed temporarily in the GUI, but edit the default here.
    # If you are happy with the current setup, do nothing.
    board = Board([4, 4, 4, 4], 0, [4, 4, 4, 4], 0)

    #### Image Paths ####
    # Replace each of the file paths with where the images are stored on your computer.
    mancalaImgPath = r"C:\Users\emma8\OneDrive\Documents\CS COURSEWORK\mancala.png"
    undoArrowImgPath = r"C:\Users\emma8\OneDrive\Documents\CS COURSEWORK\undo_arrow.png"

    #### Database Path ####
    # Replace the "C:\Users\emma8\OneDrive\Documents\Computer_Science\Mancala\users.accdb" with your file path name.
    # Leave everything else how it is.
    databasePath = r"Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\Users\emma8\OneDrive\Documents\Computer_Science\Mancala\users.accdb;"
    ##########################################

    # THE GUI IS USED BY DEFAULT. IF YOU WOULD PREFER THE TERMINAL UI, PLEASE COMMENT OUT
        # THE GUI CODE, AND UNCOMMENT THE TERMINAL UI CODE.                                   

    # ##########################################
    # ############## TERMINAL UI ###############
    # ##########################################

    # # Please edit the parameters if you would like to.
    # # NOTE: player_type = 0 is HUMAN ; 1 is EASY (COMPUTER) ; 2 is MEDIUM ; 3 is HARD.
    # # Also, player_num = 0 means that player goes first, and player_num = 1 is second.
    # player1 = Player(player_num=0, player_type=0, player_name="Bob")
    # player2 = Player(player_num=1, player_type=2, player_name="Computer - MEDIUM")

    # board.host_game(player1, player2)

    # ##########################################

    ##########################################
    ################### GUI ##################
    ##########################################

    conn = pyodbc.connect(databasePath)
    cursor = conn.cursor()

    root = Tk()

    gui = GUI(root, board, cursor, mancalaImgPath, undoArrowImgPath)
    gui.start_window()

    root.mainloop()

    conn.commit()

    ##########################################