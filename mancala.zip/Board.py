import copy
import random
from Player import Player

class Board:

    def __init__(self, side1: list[int], mancala1: list[int], side2: list[int], mancala2: list[int], player_turn=0, board_col="#FFFFFF", stones_col="#000000") -> None:
        # Board state.
        self.board_sides = [side1, side2] # 2D list
        self.mancalas = [mancala1, mancala2] # 2D list

        # Board labels. These identify hollows / mancalas.
        self.side_labels = [["A" + str(i+1) for i in range(len(side1))], ["B" + str(i+1) for i in range(len(side2))]]
        self.mancala_labels = ["AM", "BM"]

        # Useful values.
        self.board_size = sum([len(i) for i in self.board_sides]) + 2
        self.hols = (self.board_size - 2) // 2
        self.stones = sum(side1) + sum(side2) + mancala1 + mancala2

        # Useful values for formatting purposes.
        self.template = self.template_row()
        self.template_board_width = 1 + sum(sum(sect) + len(sect) for sect in self.template)

        # Initialize who goes first.
        if player_turn == -1:
            player_turn = random.choice((0,1))
        self.player_turn = player_turn # 0 = A ; 1 = B

        # Initialize end game variables.
        self.game_over = False
        self.capture = False

        # Initialize the stack that stores the board states, implemented as an array
        self.board_states = []

        # Useful for GUI implementation.
        self.board_col = board_col
        self.stones_col = stones_col

        # Store original values of the board. This allows us to reset the board later.
        self.original_board_sides = [side1, side2]
        self.original_mancalas = [mancala1, mancala2]
        self.original_player_turn = player_turn

    def reset(self) -> None:
        """
        Initialise the contents of the board to what they were originally.
        copy.deepcopy avoids aliasing.
        """
        self.board_sides = copy.deepcopy(self.original_board_sides) 
        self.mancalas = copy.deepcopy(self.original_mancalas)
        self.player_turn = copy.deepcopy(self.original_player_turn)
        self.game_over = False

    def template_row(self) -> None:
        """
        Provides a structural backbone when displaying the board in the terminal.
        """
        def width(hollow):
            return len(str(hollow)) + 2

        template = [[], [], []]
        template[0] = [width(self.mancalas[1])]
        template[2] = [width(self.mancalas[0])]
        for h in range(len(self.board_sides[0])):
            # Get the maximum width of each of the 2 holes in a given column. This will determine
                # the width of both holes.
            template[1].append(max(width(self.board_sides[0][h]), width(self.board_sides[1][h])))

        return template

    def __repr__(self) -> None:
        """
        Displays the board using | and - signs. Visual format is easy to understand for the user.
        """
        def format_hollows(hollows, template):
            row = []
            row.append(" " * 4)
            row.append(" " * template[0][0])
            row.extend([str(hollows[i]).center(template[1][i], " ") for i in range(len(self.board_sides[0]))])
            row.append(" " * template[2][0])
            row.append(" " * 4)

            return "|".join(row)

        def format_mancalas(mancalas, template):
            row = []
            row.append(" BM ")
            row.append(str(mancalas[1]).center(template[0][0], " "))
            row.extend(["-" * template[1][i] for i in range(len(self.board_sides[0]))])
            row.append(str(mancalas[0]).center(template[2][0], " "))
            row.append(" AM ")

            return "|".join(row)

        def format_dashes(template):
            return " " * 4 + " " + "-" * (self.template_board_width - 2) + " " + " " * 4

        def format_labels(labels, template):
            row = []
            row.append(" " * 4)
            row.append(" " * template[0][0])
            row.extend([str(labels[i]).center(template[1][i], " ") for i in range(len(self.board_sides[0]))])
            row.append(" " * template[2][0])
            row.append(" " * 4)

            return " ".join(row)

        print()
        print(format_labels(list(reversed(self.side_labels[1])), self.template))
        print(format_dashes(self.template_board_width))
        print(format_hollows(list(reversed(self.board_sides[1])), self.template))
        print(format_mancalas(self.mancalas, self.template))
        print(format_hollows(self.board_sides[0], self.template))
        print(format_dashes(self.template_board_width))
        print(format_labels(self.side_labels[0], self.template))
        print()

    def move(self, hol: tuple, execution=False) -> tuple:
        """
        Make a move.

        hol: tuple of the format (index in board_sides, hollow given the board side).
        execution: indicates whether a move should be executed or not. Since move method is used in minimax algorithm, in which many function calls occur to test different depths, then most of the time we do not actually want to execute a move, but simply see what the future
        board state might look like.

        returns final_hol: tuple that shows where the final stone is dropped.
        """
        # If we are actually executing the move...
        if execution:
            # Add the current board state to the stack for later retrieval.
            self.board_states.append(self.copy_board())

        # Drop the stones off in the hollows.
        # Get the stones in the starting hole, and store them in stones. Empty the starting hole.
        stones = self.board_sides[hol[0]][hol[1]] 
        self.board_sides[hol[0]][hol[1]] = 0

        # If stones > total number of holes, then we will need to go through more than one complete
            # round. We can do this by incrementing the value of each hole by quotient.
        quotient = stones // (self.board_size - 2)
        for s in range(2):
            for h in range(self.hols):
                if not (s, h) == hol: # we can't drop off in the starting hole
                    self.board_sides[s][h] += quotient
        # We only drop off in our own mancala, not the opponent's.
        self.mancalas[hol[0]] += quotient

        # Get the "remainder". This will take less than one full pass round the board.
        stones %= (self.board_size - 2)
        # If there are no stones left, the final hole is that just before the starting hole.
        if stones == 0:
            if hol[1] == 0:
                final_hol = (abs(hol[0]-1), self.hols-1)
            else:
                final_hol = (hol[0], hol[1]-1)

        # While there are still stones left to drop off, iterate over the board.
        while stones:
            # First, go over the remaining hollows on self.player_turn's side.
            for h in range(hol[1]+1, self.hols):
                self.board_sides[hol[0]][h] += 1
                stones -= 1
                if stones == 0:
                    final_hol = (hol[0], h)
                    break
            else:
                # Reaching the else clause indicates we didn't break, and that there are still stones left!
                # Drop one off in the mancala.
                self.mancalas[hol[0]] += 1
                stones -= 1
                # If we are now out of stones, then the final_hol is our (self.player_turn's) mancala.
                if stones == 0:
                    final_hol = "mancala"
                    break
                # ...otherwise, go round our opponent's holes.
                for h in range(self.hols):
                    self.board_sides[abs(hol[0]-1)][h] += 1
                    stones -= 1
                    if stones == 0:
                        final_hol = (abs(hol[0]-1), h)
                        break
                else:
                    # Reaching the else clause again means we didn't break, and there are still some stones left.
                    # Go through the holes prior to the starting hole, on self.player_turn's side.
                    for h in range(hol[1]):
                        self.board_sides[hol[0]][h] += 1
                        stones -= 1
                        if stones == 0:
                            final_hol = (hol[0], h)
                            break

        return final_hol

    def is_capture(self, final_hol: tuple) -> bool:
        """
        Determines whether a capture has occurred.
        """
        # If the final_hol is a mancala, a capture is not possible.
        if final_hol != "mancala":
            # Get the hole directly opposing.
            oppos_hol = (abs(self.player_turn-1), self.hols-final_hol[-1]-1)
            # If the final hole is on self.player_turn's side of the board, and this hole was empty until the final stone
                # was dropped here, and the opposing hole has at least 1 stone, then we have a capture!
            if final_hol[0] == self.player_turn and self.board_sides[final_hol[0]][final_hol[1]] == 1 and self.board_sides[oppos_hol[0]][oppos_hol[1]] != 0:
                return True
        return False

    def is_game_over(self) -> bool:
        """
        Checks if the game is over, and executes necessary steps if so.
        """
        # All the hollows on self.player_turn's side are empty, so self.player_turn can no longer
            # make a move.
        if sum(self.board_sides[self.player_turn]) == 0:
            # Move all stones in the opponent's hollows to the opponent's mancala.
            self.mancalas[abs(self.player_turn-1)] += sum(self.board_sides[abs(self.player_turn-1)])
            # Update the opponent's holes to be empty.
            self.board_sides[abs(self.player_turn-1)] = [0] * self.hols
            self.game_over = True
            return True

        # One player has more than half the total stones in their mancala already.
        if self.mancalas[0] > self.stones // 2 or self.mancalas[1] > self.stones // 2:
            # Assign all stones on a player's side to their mancala.
            self.mancalas[0] += sum(self.board_sides[0])
            self.mancalas[1] += sum(self.board_sides[1])
            # Set all the holes to be empty.
            self.board_sides[0] = self.hols*[0]
            self.board_sides[1] = self.hols*[0]
            self.game_over = True
            return True

        # If neither of the above if statements were executed, then the game is not over.
        return False

    def undo_move(self) -> None:
        """
        Undo one move at a time, by popping of the board states stack initialised in the __init__ method. More than one move in total can be undone, but only one at a time.
        """
        # Get the previous state by popping off the stack.
        previous_board = self.board_states.pop()
        # Update the state of the current board with previous_board's values.
        self.board_sides = copy.deepcopy(previous_board.board_sides)
        self.mancalas = copy.deepcopy(previous_board.mancalas)
        self.player_turn = copy.deepcopy(previous_board.player_turn)

    def legal_moves(self) -> list[tuple]:
        """
        Returns list of all legal moves, reperesented by their starting hollows.
        """
        # Create a list with all possible moves, then remove any illegal moves.
        legal_moves = [(self.player_turn, x) for x in range(self.hols)]
        for h in list(legal_moves):
            # If the current hole is empty, then they cannot pick up any stones, so no move is possible.
            if self.board_sides[h[0]][h[1]] == 0:
                legal_moves.remove(h)

        return legal_moves

    def copy_board(self):
        """
        Copies the current state of the board.
        """
        # If self.players has already been initialized, then carry this forward. Otherwise, do nothing.
        try:
            players = self.players
        except:
            pass

        # Create a new instance of the Board class, with exactly the same attributes as the current instance.
            # This is a deep copy that avoids aliasing.
        new_board = Board(list(self.board_sides[0]), int(self.mancalas[0]), list(self.board_sides[1]), int(self.mancalas[1]), int(self.player_turn), self.board_col, self.stones_col)

        # Carry through players if previously initialized.
        try:
            new_board.players = players
        except:
            pass

        return new_board

    def next_board(self, hol: tuple) -> tuple:
        """
        Returns the next board state, along with whether or not the current player gets an extra_move.
        """
        # Copy the board so we don't lose information about its current state.
        board = self.copy_board()

        # If the last stone falls in a mancala, then the current player can move again.
        if board.move(hol) == "mancala":
            # Don't update player_turn here.
            extra_move = True
        else:
            extra_move = False
            # Update the player_turn associated with this new board.
            board.player_turn = abs(self.player_turn-1)

        return board, extra_move, hol # hol indicates which hollow led to the next_board state

    def evaluation(self) -> float:
        """
        Evaluate the board at a given node, using heuristics. The closer the node is to a leaf node, the more
            accurate this evaluation will be.
        """
        def x1():
            # x1 := stones in self.player_turn's mancala - stones in opponent's mancala
            return self.mancalas[self.player_turn] - self.mancalas[abs(self.player_turn-1)]

        def x2():
            # x2 := no. of potential capturing opportunities for self.player_turn
            ct = 0
            # Iterate through the holes on self.player_turn's side, checking for captures.
            for hol in [(self.player_turn, x) for x in range(self.hols)]:
                board = self.copy_board()
                res = board.move(hol)
                if board.is_capture(res):
                    ct += 1

            return ct

        def x3():
            # x3 := no. of potential capturing opportunities for opponent
            ct = 0
            # Iterate through the holes on the opponent's side, checking for captures.
            for hol in [(abs(self.player_turn-1), x) for x in range(self.hols)]:
                board = self.copy_board()
                res = board.move(hol)
                if board.is_capture(res):
                    ct += 1

            return ct

        def x4():
            # x4 := no. of potential chaining opportunities for self.player_turn
            ct = 0
            # Iterate through the holes on self.player_turn's side, checking for chaining opportunities.
            for hol in [(self.player_turn, x) for x in range(self.hols)]:
                board = self.copy_board()
                res = board.move(hol)
                if res == "mancala": # chaining opportunity spotted
                    ct += 1
                else:
                    continue

            return ct

        x1, x2, x3, x4 = x1(), x2(), x3(), x4()
        # These weights have been determined empirically by others.
        w1, w2, w3, w4 = 0.45, 0.05, -0.1, 0.1

        return x1*w1 + x2*w2 + x3*w3 + x4*w4

    def host_game(self, player1: Player, player2: Player, undo_move_activated=False) -> None:
        """
        Hosts game between 2 players: player1 and player2. Provides a visual UI in the terminal.

        undo_move_activated: indicates whether or not to make the undo move option available. Having the option is slightly clunky in the Terminal version (as opposed to the GUI).
        """
        # Reset the board at the beginning of each game.
        self.reset()

        # Display the total number of stones in the game.
        print("\nTotal number of stones in game =", self.stones)

        # Initialize self.players for ease of reference.
        self.players = (player1, player2) if player1.player_num == 0 else (player2, player1)

        # Display the board.
        self.__repr__()

        # While the game is still running...
        while True:
            # Display whose turn it is.
            print(f"{self.players[self.player_turn].player_name} turn")

            # Get the hollow that will be selected next.
            hol = self.players[self.player_turn].choose_move(self)

            # Find the corresponding final hollow if hol is selected.
            final_hol = self.move(hol, execution=True)

            # See if there is a capture (i.e., the last stone to be dropped lands in an empty hollow on self.player_turn's
                # side, and the opposing hollow is not empty).
            if self.is_capture(final_hol):
                # Get the opposing hole.
                oppos_hol = (abs(self.player_turn-1), self.hols-final_hol[-1]-1)
                # Update self.player_turn's mancala.
                self.mancalas[final_hol[0]] += self.board_sides[final_hol[0]][final_hol[1]] + self.board_sides[oppos_hol[0]][oppos_hol[1]]
                # Set bost final_hol and oppos_hol to 0 (all the stones have been removed and added to self.player_turn's mancala).
                self.board_sides[final_hol[0]][final_hol[1]] = 0
                self.board_sides[oppos_hol[0]][oppos_hol[1]] = 0

            # Display the board again after the move has been made so that the user can see the changes.
            self.__repr__()

            ################################################################
            ################### UNDO MOVE FUNCTIONALITY ####################
            ################################################################

            move_undone = False
            if undo_move_activated:
                # Check that self.player_turn is a human.
                if self.players[self.player_turn].player_type == 0:
                    undo = input("Undo move? (yes/no) ")
                    if undo.lower() == "yes":
                        # Display the previous board state.
                        self.board_states[-1].__repr__()
                        # Undo the move.
                        self.undo_move()
                        move_undone = True
                    else:
                        self.__repr__()
            
            ################################################################

            # Check to see if game is over after each move.
            if self.is_game_over():
                print("Game Over.")
                self.__repr__()
                # If so, break from the loop.
                break

            # Update self.player_turn if chaining did not occur.
            if final_hol != "mancala" and not move_undone:
                self.player_turn = abs(self.player_turn-1)

        #### Here, we have exited the main loop. #####
    
        # Determine the result of the game.
        if self.mancalas[0] == self.mancalas[1]:
            print("Draw")
        else:
            winner = 0 if self.mancalas[0] > self.mancalas[1] else 1
            loser = abs(winner-1)

        # Display the results in the terminal.
        print("Winner:", self.players[winner].player_name)
        print("Loser:", self.players[loser].player_name)