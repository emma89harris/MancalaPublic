import pyautogui
import string
import random
from tkinter import *
from PIL import ImageTk, Image
from DB import DB
from Player import Player
from Board import Board
import copy
import pyodbc

# When done, go through and look at break points inserted when editing.

class GUI:

    # Determine the positioning of the window with respect to each specific screen, as this
        # may very between users.
    SCREEN_WIDTH, SCREEN_HEIGHT = pyautogui.size()
    WIDTH_SCALING_FACTOR, HEIGHT_SCALING_FACTOR = 1600/1920, 888/1080
    WINDOW_WIDTH = int(WIDTH_SCALING_FACTOR * SCREEN_WIDTH)
    WINDOW_HEIGHT = int(HEIGHT_SCALING_FACTOR * SCREEN_HEIGHT)

    # Constant that are used throughout program.
    FIRST_LOC, BUTTON_SPACING, ENTRY_SPACING = 245, 110, 100
    # Initialize distance between centers of hollows.
    HOL_SPACING = 170

    # This file stores previously saved games for later access.
    SAVED_GAMES = "saved_games.txt"

    def __init__(self, master: Tk, board: Board, cursor: pyodbc.Cursor, mancalaImgPath: str, undoArrowImgPath: str) -> None:
        """
        Constructor method for the GUI class.
        """
        self.board = board

        self.root = master
        self.root.title("Mancala")

        # These variables force the computer to wait before displaying board changes. Otherwise,
            # moves would happen in the blink of an eye!
        # Execution time for a move.
        self.move_speed = 500
        # Time between moves.
        self.wait = 200

        # Get the coordinates of the top-left corner of the game window.
        x_coord = (self.SCREEN_WIDTH - self.WINDOW_WIDTH) // 2
        y_coord = (self.SCREEN_HEIGHT - self.WINDOW_HEIGHT) // 2 - self.y_pos(55)

        # Set the dimensions of the Tkinter window (first 2 terms) and position the window (last 2 terms).
        self.root.geometry(f"{self.WINDOW_WIDTH}x{self.WINDOW_HEIGHT}+{x_coord}+{y_coord}")

        # Initialize username to "" for now. This will be updated later.
        self.username = ""

        # Pass in "cursor" to access the specific database we want.
        self.DB = DB(cursor)

        # Store the path for the image of the mancala board (for start window and quit window).
        self.mancalaImgPath = mancalaImgPath
        # Store the path for the icon of the undo arrow.
        self.undoArrowImgPath = undoArrowImgPath

    def x_pos(self, loc: int) -> int:
        """
        This is a scaling function. It returns the x coordinate of a point on the window
            as a function of the window width. This allows for portability.
        """
        return int(loc/1600 * self.WINDOW_WIDTH)

    def y_pos(self, loc: int) -> int:
        """
        This is a scaling function. It returns the y coordinate of a point on the window
            as a function of the window width. This allows for portability.
        """
        return int(loc/888 * self.WINDOW_HEIGHT)

    def base_window(self, title = "", description = "", logged_in = True) -> None:
        """
        This is a window with basic features that are common among all the windows
            that might be displayed as the user uses the app.

        If the user is logged in, then a button appears in the top-right corner of the
            window, labelled "Logout". The user can click this to log out should they
            wish to.
        """
        # Remove any existing canvas.
        try:
            self.canvas.destroy()
        except AttributeError:
            pass

        # Create a new canvas.
        self.canvas = Canvas(self.root, width=self.WINDOW_WIDTH, height=self.WINDOW_HEIGHT)
        # Organize widgets into blocks.
        self.canvas.pack()
        # Set the background color.
        self.canvas.configure(bg="#BBDEFD")
        
        # Position the "Logout" icon in the top-right corner of window.
        if logged_in:
            # Create a button.
            button = Button(self.root, text="Logout", font="{Calisto MT} 15 bold", command=self.log_out)
            # Position the button.
            button.place(x=self.x_pos(1570), y=self.y_pos(30), anchor=NE)

        # General instructions for displaying the "title" and "description", which are passed in as the "text" parameter.
        self.canvas.create_text(self.x_pos(40), self.y_pos(30), anchor=NW, text=title, font="{Calisto MT} 44 bold underline")
        self.canvas.create_text(self.x_pos(40), self.y_pos(130), anchor=NW, text=description, font="{Calisto MT} 28 bold", width=self.WINDOW_WIDTH-100)

        # No "self.root.mainloop()" here. This is because we don't want an infinite loop, as the base_window
            # method is shared among many methods.

    def start_window(self) -> None:
        """
        This window starts from scratch, and does not use the base window. This is because the background is not the
            signature blue of the base window, but a specified image (mancala.png).
        """
        # Remove any existing canvas.
        try:
            self.canvas.destroy()
        except:
            pass

        # Create a new canvas.
        self.canvas = Canvas(self.root, width=self.WINDOW_WIDTH, height=self.WINDOW_HEIGHT)
        self.canvas.pack()

        # Open the image of the mancala board.
        img = Image.open(self.mancalaImgPath)
        # Resize the image to fit the specific window.
        resized_img = img.resize((self.WINDOW_WIDTH, self.WINDOW_HEIGHT))
        # Create an image object that can be used whenever needed. Assign it to the variable new_image.
        new_image = ImageTk.PhotoImage(resized_img)

        # Display background image (mancala board).
        self.canvas.create_image(self.x_pos(800), self.y_pos(444), anchor=CENTER, image=new_image)
        # Display title.
        self.canvas.create_text(self.x_pos(800), self.y_pos(319), anchor=CENTER, text="Welcome to Mancala!", fill="#FFE89F", font="{Calisto MT} 60 bold")

        # This button is displayed in the middle of the screen. When clicked, functionality is passed to the user_mode_menu
            # method, defined below.
        # Button functionality.
        button = Button(self.root, text="Click to Start", command=self.user_mode_menu, font="{Calisto MT} 30", width=14, height=2)
        # Position the button.
        button.place(x=self.x_pos(800), y=self.y_pos(540), anchor=CENTER)

        # Initiate the infinite loop (event loop) in this method.
        self.root.mainloop()

    def user_mode_menu(self) -> None:
        """
        This is the User Mode Menu. There are 4 options here, as can be seen in the comments below.

        Each button has a different value for the "command" parameter. This directs the program to a different method
            depending on which button is clicked. e.g., if button2 is clicked, the sign_up method is called.
        """
        # Call the base_window method to initialize basic features, such as blue background, title, description.
        self.base_window("User Mode Menu", "Please choose the mode you would like to play in to continue:", logged_in=False)

        ############################################################################################
        ############################    User Mode Menu Options   ###################################
        ############################################################################################

        # 1. Log In
        button1 = Button(self.root, text="1", font="{Calisto MT} 28 bold", width=3, height=1, command=self.log_in)
        button1.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC), anchor=W, text="Log in", font="{Calisto MT} 28 bold")

        # 2. Sign Up
        button2 = Button(self.root, text="2", font="{Calisto MT} 28 bold", width=3, height=1, command=self.sign_up)
        button2.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+self.BUTTON_SPACING), anchor=W, text="Sign up", font="{Calisto MT} 28 bold")

        # 3. Browse as Guest
        button3 = Button(self.root, text="3", font="{Calisto MT} 28 bold", width=3, height=1, command=self.browse_guest)
        button3.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+2*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+2*self.BUTTON_SPACING), anchor=W, text="Browse as Guest", font="{Calisto MT} 28 bold")

        # 4. Quit Program
        button4 = Button(self.root, text="4", font="{Calisto MT} 28 bold", width=3, height=1, command=lambda:self.quit_program("user mode menu"))
        button4.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+3*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+3*self.BUTTON_SPACING), anchor=W, text="Quit Program", font="{Calisto MT} 28 bold")

        ############################################################################################

        # No self.root.mainloop() here, as we do not want an infinite loop.

    def log_in(self) -> None:
        """
        This is the Log In portal. In order to complete log in, press the "Return" key on the keyboard.

        After this, we move to the greeting method.
        """
        # Create the base window.
        self.base_window("Log in portal", "Please enter username and password.\nPress the 'Enter' when done.", logged_in=False)

        ############################################################################################
        ############################         Entry Boxes         ###################################
        ############################################################################################

        # Create the Username entry box. This is where the user types their username.
        entry1 = Entry(self.root, font="{Calisto MT} 17")
        entry1.pack()
        self.canvas.create_window(self.x_pos(800), self.y_pos(350), window=entry1, width=400, height=80)
        self.canvas.create_text(self.x_pos(440), self.y_pos(350), text="Username:", font="{Calisto MT} 28 bold")

        # Create the Password entry box. This is where the user types their password.
        entry2 = Entry(self.root, show="●", font="{Calisto MT} 10")
        entry2.pack()
        self.canvas.create_window(self.x_pos(800), self.y_pos(450), window=entry2, width=400, height=80)
        self.canvas.create_text(self.x_pos(440), self.y_pos(350+self.ENTRY_SPACING), text="Password:", font="{Calisto MT} 28 bold")

        ############################################################################################

        def set_details(return_key=None):
            """
            This nested function retrieves information carries out verification checks, before retrieving
                the information relevant to the given username and password.
            """
            # Retrieve the values typed into the entry boxes.
            self.username = entry1.get()
            # Note that we want to hash the password typed to make the system a little more secure.
            self.password = str(self.DB.hash(entry2.get()))

            # Since the user is logging in (as opposed to signing up), then their username must actually exist in
                # the database. Check that this is the case.
            if self.username in self.DB.get_usernames():
                # Given that the username exists, the typed password must match the stored password.
                if self.password == self.DB.get_password(self.username):
                    # Each user has a number of different preferences (e.g., board color). When
                        # the user logs in, we want to update certain features of the program to
                        # match these preferences.
                    self.load_preferences()
                    # We are now done processing 
                    self.greeting()
                else:
                    # Throw an error. Typed password must match stored password.
                    self.error_message("Password does not match username.")
            else:
                # Throw an error. Username must exist (as this is a log in portal not a sign up portal).
                self.error_message("Username not in database.")

        # When the user presses the <Return> key, set_details is called. Definition above.
        self.root.bind("<Return>", set_details)

        # There is a "Back" button in the bottom-right corner that allows the user to return to the User Mode Menu.
        button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.user_mode_menu)
        button.place(x=self.x_pos(1500), y=self.y_pos(800), anchor=SE)

    def sign_up(self) -> None:
        """
        This is the Sign Up portal. In order to complete sign up, press the "Return" key on the keyboard.

        After this, we are taken to the greeting method.
        """
        # Create the base window.
        self.base_window("Sign up portal", "Please enter username and password.\nPress the 'Enter' when done.", logged_in=False)

        ############################################################################################
        ############################         Entry Boxes         ###################################
        ############################################################################################

        # Username
        entry1 = Entry(self.root, font="{Calisto MT} 17")
        entry1.pack()
        self.canvas.create_window(self.x_pos(970), self.y_pos(350), window=entry1, width=400, height=80)
        self.canvas.create_text(self.x_pos(380), self.y_pos(350), anchor=W, text="Username:", font="{Calisto MT} 28 bold")

        # Password
        entry2 = Entry(self.root, show="●", font="{Calisto MT} 10")
        entry2.pack()
        self.canvas.create_window(self.x_pos(970), self.y_pos(350+self.ENTRY_SPACING), window=entry2, width=400, height=80)
        self.canvas.create_text(self.x_pos(380), self.y_pos(350+self.ENTRY_SPACING), anchor=W, text="Password:", font="{Calisto MT} 28 bold")

        # Re-type Password
        entry3 = Entry(self.root, show="●", font="{Calisto MT} 10")
        entry3.pack()
        self.canvas.create_window(self.x_pos(970), self.y_pos(350+2*self.ENTRY_SPACING), window=entry3, width=400, height=80)
        self.canvas.create_text(self.x_pos(380), self.y_pos(350+2*self.ENTRY_SPACING), anchor=W, text="Re-type Password:", font="{Calisto MT} 28 bold")

        ############################################################################################

        def set_details(return_key=None):
            # See notes in set_details function in log_in method above.
            self.username = entry1.get()
            self.password = self.DB.hash(entry2.get())
            password_check = self.DB.hash(entry3.get())

            # Usernames must be unique, so the typed username can't have been seen before.
            if self.username not in self.DB.get_usernames():
                # Check the re-typed password didn't contain a typo.
                if self.password == password_check:
                    # Add user to the database.
                    self.DB.create_user(self.username, self.password)
                    # Load greeting window.
                    self.greeting()
                else:
                    self.error_message("Passwords do not match.")
            else:
                self.error_message("Username already taken.")

        # Call set_details function when the Return key is pressed.
        self.root.bind("<Return>", set_details)

        # "Back" button in the bottom-right corner to return to the User Mode Menu.
        button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.user_mode_menu)
        button.place(x=self.x_pos(1500), y=self.y_pos(800), anchor=SE)

    def log_out(self) -> None:
        """
        This is a "buffer" page when a user logs out. It displays the message "Logging out [username]..." for a set period of time,
            defined by self.wait. This helps to keep the user informed, and prevent actions from happening in a split second.

        After logging out, the user is returned to the User Mode Menu.
        """
        # logged_in parameter is set to False, because we don't want the "Logout" option in the top-right corner.
        self.base_window(logged_in=False)

        # Display a short message to inform the user that they are being logged out.
        self.canvas.create_text(self.x_pos(80), self.y_pos(130), anchor=NW, text=f"Logging out {self.username}...", font="{Calisto MT} 28 bold")

        # After self.wait time, move back to the User Mode Menu.
        self.canvas.after(self.wait, self.user_mode_menu)

    def error_message(self, message="") -> None:
        """
        This displays an error message, personalized by the "message" parameter.
        """
        try:
            # If an error message already exists, just edit the current one.
            self.canvas.itemconfig(self.error, text=message)
        except:
            # ...otherwise, we need to create the self.error object.
            self.error = self.canvas.create_text(self.x_pos(400), self.y_pos(700), anchor=CENTER, text=message, font="{Calisto MT} 20 bold")

    def browse_guest(self) -> None:
        """
        The user does not need to log in or sign up. Instead, they can "Browse as Guest". However, changes won't be saved
            in this mode.
        """
        self.username = "Guest"
        self.password = None

        self.greeting()

    def greeting(self) -> None:
        """
        This is the "buffer" page before taking the user to the Main Menu.
        """
        # We don't want the "Logout" icon in the top-right corner.
        self.base_window(logged_in=False)

        # Display a short message on the screen to inform the user what is happening.
        self.canvas.create_text(self.x_pos(80), self.y_pos(130), anchor=NW, text=f"Hello {self.username}!", font="{Calisto MT} 28 bold")
        self.canvas.create_text(self.x_pos(80), self.y_pos(270), anchor=NW, text="Loading Main Menu...", font="{Calisto MT} 28 bold")

        # Move to the Main Menu.
        self.canvas.after(self.wait, self.main_menu)

    def main_menu(self, return_key=None) -> None:
        """
        This method displays the Main Menu. To select an option, the user should click the number of the option
            they would like. Each button has a different "command" parameter, which will determine which window
            the user is taken to next. e.g., if the user clicks 1, they are taken to the Game Menu.
        """
        # Load the base window.
        self.base_window("Main Menu", "Please select an option:")

        ############################################################################################
        ############################       Main Menu Options     ###################################
        ############################################################################################

        # 1. Play Game
        button1 = Button(self.root, text="1", font="{Calisto MT} 28 bold", width=3, height=1, command=self.game_menu)
        button1.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC), anchor=W, text="New Game", font="{Calisto MT} 28 bold")

        # 2. Resume Game (that has previously been saved)
        button2 = Button(self.root, text="2", font="{Calisto MT} 28 bold", width=3, height=1, command=self.resume_game)
        button2.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+self.BUTTON_SPACING), anchor=W, text="Resume Game", font="{Calisto MT} 28 bold")

        # Display Rules
        button3 = Button(self.root, text="3", font="{Calisto MT} 28 bold", width=3, height=1, command=lambda:self.rules("main menu"))
        button3.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+2*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+2*self.BUTTON_SPACING), anchor=W, text="View Rules", font="{Calisto MT} 28 bold")

        # Configure Gameboard
        button4 = Button(self.root, text="4", font="{Calisto MT} 28 bold", width=3, height=1, command=lambda:self.config_menu("main menu"))
        button4.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+3*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+3*self.BUTTON_SPACING), anchor=W, text="Configure Gameboard", font="{Calisto MT} 28 bold")

        # View Leaderboard
        button5 = Button(self.root, text="5", font="{Calisto MT} 28 bold", width=3, height=1, command=self.leaderboard)
        button5.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+4*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+4*self.BUTTON_SPACING), anchor=W, text="View Leaderboard", font="{Calisto MT} 28 bold")

        # Quit Program
        button6 = Button(self.root, text="6", font="{Calisto MT} 28 bold", width=3, height=1, command=self.quit_program)
        button6.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+5*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+5*self.BUTTON_SPACING), anchor=W, text="Quit Program", font="{Calisto MT} 28 bold")
        
        ############################################################################################

    def game_menu(self) -> None:
        """
        This allows the user to choose which type of game they want to play.
            1. Single player - they play against the computer.
            2. Multi player - they play against a friend (on the same computer).
            3. Computer battle - the computer plays itself!

        See main_menu method for more details about the implementation.
        """
        # Load the base window.
        self.base_window("Game Menu", "Please select an option:")

        # "Back" button to return to Main Menu.
        button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.main_menu)
        button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

        ############################################################################################
        ############################       Game Menu Options     ###################################
        ############################################################################################

        # 1. Single Player
        button1 = Button(self.root, text="1", font="{Calisto MT} 28 bold", width=3, height=1, command=self.single_player)
        button1.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC), anchor=W, text="Single player", font="{Calisto MT} 28 bold")

        # Multi Player
        button2 = Button(self.root, text="2", font="{Calisto MT} 28 bold", width=3, height=1, command=self.multi_player)
        button2.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+self.BUTTON_SPACING), anchor=W, text="Multi player", font="{Calisto MT} 28 bold")

        # Computer Battle
        button3 = Button(self.root, text="3", font="{Calisto MT} 28 bold", width=3, height=1, command=self.computer_battle)
        button3.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+2*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+2*self.BUTTON_SPACING), anchor=W, text="Computer battle", font="{Calisto MT} 28 bold")

        ############################################################################################

    def single_player(self) -> None:
        """
        Here, the user will play the computer, and the 3 options are:
            1. Easy
            2. Medium
            3. Hard
        """
        # Load the base window.
        self.base_window("Single Player Menu", "Please select an option:")

        # "Back" button returns user to the Game Menu.
        button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.game_menu)
        button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

        def difficulty(level: int) -> None:
            """
            This is a helper function that takes in the difficulty "level" as a parameter, and constructs
                the Player objects accordingly.
            
            We then jump to the player_order method (Single Player Menu).
            """
            # Pass in player_num as -1 for now, as we are yet to decide who goes first. This parameter
                # will be updated later.
            levels = ("Easy", "Medium", "Hard")

            computer = Player(-1, level, f"Computer ({levels[level-1]})")
            human = Player(-1, 0, self.username)

            self.board.players = (human, computer)

            # Jump to Single Player Menu.
            self.player_order("single player menu")

        ############################################################################################
        ###########################  Single Player Menu Options  ###################################
        ############################################################################################

        # 1. Easy
        button1 = Button(self.root, text="1", font="{Calisto MT} 28 bold", width=3, height=1, command=lambda:difficulty(1))
        button1.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC), anchor=W, text="Easy", font="{Calisto MT} 28 bold")

        # 2. Medium
        button2 = Button(self.root, text="2", font="{Calisto MT} 28 bold", width=3, height=1, command=lambda:difficulty(2))
        button2.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+self.BUTTON_SPACING), anchor=W, text="Medium", font="{Calisto MT} 28 bold")

        # 3. Hard
        button3 = Button(self.root, text="3", font="{Calisto MT} 28 bold", width=3, height=1, command=lambda:difficulty(3))
        button3.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+2*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+2*self.BUTTON_SPACING), anchor=W, text="Hard", font="{Calisto MT} 28 bold")

        ############################################################################################

    def multi_player(self) -> None:
        """
        Currently, multi-player games cannot be saved. They are played over the same interface between humans.
        """
        # Load the base window.
        self.base_window(title="Multi Player Game", description="Enter player names:")

        # "Back" button returns the user to the Game Menu.
        button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.game_menu)
        button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

        ###################################################################################
        ###########################  Player Name Boxes  ###################################
        ###################################################################################

        # Player 1 Name
        entry1 = Entry(self.root, font="{Calisto MT} 17")
        entry1.pack()
        self.canvas.create_window(self.x_pos(800), self.y_pos(350), window=entry1, width=400, height=80)
        self.canvas.create_text(self.x_pos(440), self.y_pos(350), text="Player 1:", font="{Calisto MT} 28 bold")

        # Player 2 Name
        entry2 = Entry(self.root, font="{Calisto MT} 17")
        entry2.pack()
        self.canvas.create_window(self.x_pos(800), self.y_pos(450), window=entry2, width=400, height=80)
        self.canvas.create_text(self.x_pos(440), self.y_pos(350+self.ENTRY_SPACING), text="Player 2:", font="{Calisto MT} 28 bold")

        ###################################################################################

        def create_players(return_key=None) -> None:
            """
            This is a helper function. It constructs the 2 Player objects, and then moves to the
                Multi Player Menu.
            """
            human1 = Player(-1, 0, entry1.get())
            human2 = Player(-1, 0, entry2.get())

            self.board.players = (human1, human2)

            # Jump to multi-player menu.
            self.player_order("multi player menu")

        # When the Return key is pressed, call the create_players function.
        self.root.bind("<Return>", create_players)

    def player_order(self, source: str) -> None:
        """
        This allows the user to choose which player goes first. There are 3 options:
            1. User goes first.
            2. User goes second.
            3. Computer randomly assigns whether user goes first or second.
        
        Once this assignment is made, the game begins! Call the host_game method.

        See main_menu method for more details about the implementation.
        """
        # Load base window.
        self.base_window("Player Order", f"Please choose whether {self.board.players[0].player_name} goes first or second (or whether this is generated randomly):") 

        # Depending on whether we came from the Single Player Menu or the Multi Player Menu, we want to return
            # to the window we were previously on. This is the purpose of the selection statement below.
        # The "command" parameter is assigned self.single_player or self.multi_player, depending on the result
            # of the selection statement.
        if source == "single player menu":
            button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.single_player)
            button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)
        elif source == "multi player menu":
            button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.multi_player)
            button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

        def assign(loc=random.choice((0,1))):
            """
            This helper function assigns the user to go first (loc==0) or second (loc==1). If no parameter is passed,
                the default is a random choice between the 2.
            """
            # Set the value of the player_turn attribute in the Board class to loc.
            self.board.player_turn = loc

            # Update the value of player_num for each of the Player objects, stored in the Board object.
            self.board.players[0].player_num = loc
            self.board.players[1].player_num = abs(loc-1)

            if loc == 1:
                self.board.players = (self.board.players[1], self.board.players[0]) # always have so that index 0 has player_num = 0
            
            # Begin the game!
            self.host_game()

        ############################################################################################
        ############################     Player Order Options    ###################################
        ############################################################################################

        # 1. User goes first
        button1 = Button(self.root, text="1", font="{Calisto MT} 28 bold", width=3, height=1, command=lambda:assign(0))
        button1.place(x=self.x_pos(180), y=self.y_pos(275), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(275), anchor=W, text="First", font="{Calisto MT} 28 bold")

        # 2. User goes second
        button2 = Button(self.root, text="2", font="{Calisto MT} 28 bold", width=3, height=1, command=lambda:assign(1))
        button2.place(x=self.x_pos(180), y=self.y_pos(275+self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(275+self.BUTTON_SPACING), anchor=W, text="Second", font="{Calisto MT} 28 bold")

        # 3. Random assignment
        button3 = Button(self.root, text="3", font="{Calisto MT} 28 bold", width=3, height=1, command=assign)
        button3.place(x=self.x_pos(180), y=self.y_pos(275+2*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(275+2*self.BUTTON_SPACING), anchor=W, text="Random", font="{Calisto MT} 28 bold")

        ############################################################################################

    def computer_battle(self) -> None:
        """
        This function is mainly for proof that the 'harder' algorithm can beat the 'easier' algorithm.
        """
        # Construct the 2 Player objects (both are computers).
        computer1 = Player(0, 2, "Medium")
        computer2 = Player(1, 3, "Hard")

        self.board.players = (computer1, computer2)

        # Jump to the host_game method.
        self.host_game()

    def host_game(self, new_game=True) -> None:
        """
        Host the game.

        new_game: bool -- if True, then reset the board. By default, we assume the game is a new game.
        """
        if new_game: # reset the board
            self.board.reset()
            try:
                self.board.previous_board.reset() # reset previous_board too
            except: # first game
                pass

        self.base_window()

        # Determine the coordinates of the centre of the screen.
        centre_x = self.WINDOW_WIDTH // 2
        centre_y = self.WINDOW_HEIGHT // 2

        # "Options" button, situated in the bottom right.
        button = Button(self.root, text="Options", font="{Calisto MT} 24 bold", command=self.game_options)
        button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

        # "Undo" button, an image situated in the bottom left.
        img = Image.open(self.undoArrowImgPath)
        resized_img = img.resize((100, 100))
        new_image = ImageTk.PhotoImage(resized_img)

        # Construct the button.
        self.undo_button = Button(self.root, image=new_image, command=self.undo_move)
        self.undo_button.place(x=self.x_pos(50), y=self.y_pos(844), anchor=SW)

        # Initially, there are no previous moves, so we want to disable the undo button.
        self.undo_button["state"] = "disabled"

        # Label each user's side of the board.
        self.canvas.create_text(self.x_pos(centre_x), self.y_pos(180), anchor=CENTER, text=f"{self.board.players[1].player_name}", font="{Calisto MT} 26 bold")
        self.canvas.create_text(self.x_pos(centre_x), self.y_pos(self.WINDOW_HEIGHT-180), anchor=CENTER, text=f"{self.board.players[0].player_name}", font="{Calisto MT} 26 bold")

        def canvas_x_loc(h: int) -> int:
            """
            This is a helper function that gets the x-coordinate of a given hole number (h), positioning
                it with respect to the centre (centre_x), based on the total number of holes (given by
                self.board.hols).
            """
            if self.board.hols % 2 == 0: # if there is an even number of holes
                return centre_x - self.HOL_SPACING // 2 * (1 + 2 * (self.board.hols // 2 - 1 -h))
            else: # if there is an odd number of holes
                return centre_x - self.HOL_SPACING * (self.board.hols // 2 - h)

        def canvas_y_loc(s: int) -> int:
            """
            This is a helper function that gets the y-coordinate. s is either 1 or -1.
            We only need 2 possible scenarios as there are only 2 rows of holes (one for each player).

            s==-1 is the bottom row. This is because y is increasing down the screen ((0,0) is in the top-left corner).
            """
            return centre_y - s * 87

        # Each sublist stores the holes for a given player. The sublist at index 0 is player1,
            # and the sublist at index 1 is player2.
        self.hol_buttons = [[None]*self.board.hols, [None]*self.board.hols]
        # Mancalas are treated distinctly from holes, as they have different properties, so are stored
            # in a separate list. Again, index 0 is player1, index 1 is player2.
        self.mancala_buttons = [None, None]

        # Display the total number of stones in the game at the bottom of the screen (below the board).
        self.canvas.create_text(self.x_pos(250), self.y_pos(800), anchor=W, text=f"Total number of stones: {self.board.stones}", font="{Calisto MT} 26 bold")

        #######################################################################################
        ################## CREATING AND DISPLAYING THE BUTTONS FOR HOLES ######################
        #######################################################################################

        # Iterate over each row. s==-1 is the bottom row, s==1 is the top row.
        for s in (-1, 1):
            # If s==-1, then we are looking at the bottom row (i.e., player 1).
            side = 0 if s==-1 else 1

            # Make deep copies to prevent aliasing when we make in-place changes.
            side_labels = copy.deepcopy(self.board.side_labels[side])
            side_hols = copy.deepcopy(self.board.board_sides[side])
            
            # If we are looking at the top row, then we want to reverse the holes, as they will be
                # displayed the other way round as seen by the user.
            if side == 1:
                side_labels.reverse()
                side_hols.reverse()

            # Iterate over each hole in a row.
            for h in range(self.board.hols): # NOTE: self.board.hols is the number of holes on ONE side (not total number of holes).
                # side_labels stores labels such as "A3" where 3 is the hole number.
                # index thus stores the side (bottom or top row) and the particular hole in that row.
                index = (side, int(side_labels[h][1:])-1)

                # Create the button for hole h.
                button = Button(self.root, text=f"{side_hols[h]}", font="{Calisto MT} 32 bold", width=5, height=2, command=lambda index=index:self.move(index, True), bg=self.board.board_col, activebackground=self.board.board_col, fg=self.board.stones_col, activeforeground=self.board.stones_col, disabledforeground=self.board.stones_col)
                # Position the button on the canvas.
                button.place(x=canvas_x_loc(h), y=canvas_y_loc(s), anchor=CENTER)

                # We want the button to function normally as the user should be able to click on it
                    # to make a move.
                button["state"] = "normal"

                # Display the hole labels.
                self.canvas.create_text(canvas_x_loc(h), canvas_y_loc(s)-s*115, anchor=CENTER, text=f"{side_labels[h]}", font="{Calisto MT} 28 bold")

                # Store the button we constructed earlier in the relevant index in self.hol_buttons.
                if side == 0: # bottom row
                    self.hol_buttons[side][h] = button
                else: # top row
                    # We have to account for the fact the top row is reversed.
                    self.hol_buttons[side][self.board.hols-h-1] = button

        #######################################################################################

        #######################################################################################
        ################ CREATING AND DISPLAYING THE BUTTONS FOR MANCALAS #####################
        #######################################################################################

        # Get a copy of all the mancala labels to prevent aliasing.
        mancala_labels = list(self.board.mancala_labels)

        # Create both mancalas. 
        for m in (-1, self.board.hols):
            # m==-1 is the leftmost mancala, which belongs to player 2, and thus the top row (side==1).
            # The canvas_x_loc helper function returns the position of the ith hole, where i is the
                # parameter. Thus, if we pass in -1 as the parameter, it will go "one more to the left"
                # of the leftmost hole. This is indeed where the mancala should go.
            # Similarly, when we pass in parameter self.board.hols, it will go "one more to the right"
                # than the rightmost hole.
            side = 1 if m==-1 else 0

            # Create and place the mancala on the canvas.
            mancala = Button(self.root, text=f"{self.board.mancalas[side]}", font="{Calisto MT} 32 bold", width=5, height=5, bg=self.board.board_col, disabledforeground=self.board.stones_col)
            mancala.place(x=canvas_x_loc(m), y=centre_y, anchor=CENTER)

            # Place the mancala labels on the canvas.
            self.canvas.create_text(canvas_x_loc(m)+m//abs(m)*150, centre_y, anchor=CENTER, text=f"{mancala_labels[side]}", font="{Calisto MT} 28 bold")

            # Disable the mancala button as we can't access mancalas.
            mancala["state"] = "disabled"

            # Store the newly-created button in self.mancala_buttons.
            self.mancala_buttons[side] = mancala

        #######################################################################################

        # first move executed here -- then .move() calls itself
        if self.board.players[self.board.player_turn].player_type != 0: # computer's move
            # Disable all buttons as the user cannot move at this time.
            self.disable_buttons()
            # Display that it is the computer's turn.
            self.show_player_turn(True)

            # The choose_move method identifies the player type, and then chooses a hole
                # based on that. e.g., if the player type is HUMAN, then it will take user
                # input. If instead the player type is MEDIUM, then it will choose the hole
                # itself based on the result of the minimax algorithm.
            move_hol = self.board.players[self.board.player_turn].choose_move(self.board)
            # Execute the move, and then get the final hole.
            # We want to make a copy because the move method actually executes the move, but
                # we don't want to lose the previous state just yet.
            final_hol = self.board.copy_board().move(move_hol)

            # Highlight move_hol for self.move_speed length of time.
            self.highlight_hols(self.board.players[self.board.player_turn].player_type, (move_hol, final_hol))
            # Execute the move.
            self.canvas.after(self.move_speed, lambda:self.move(move_hol))
            # Remove the text displaying whose turn it is.
            self.show_player_turn()
        else: # human's move
            # Enable the buttons to allow the user to pick which hole to move from.
            self.enable_buttons()
            # 0 parameter indicates that it is a HUMAN playing.
            self.highlight_hols(0)
            # Display whose turn it is.
            self.show_player_turn(True)

        self.root.mainloop()

    def capture(self, final_hol: tuple) -> None:
        """
        Execute a capture if it exists.

        final_hol is of the format (player number, hole number).
        """
        # Find out if there is a capture.
        if self.board.is_capture(final_hol):
            # Display text indicating that a capture has occurred.
            try:
                self.canvas.itemconfig(self.capture_message, text=f"Capture by {self.board.players[self.board.player_turn].player_name}!")
            except:
                self.capture_message = self.canvas.create_text(self.x_pos(1000), self.y_pos(50), anchor=W, text=f"Capture by {self.board.players[self.board.player_turn].player_name}!", font="{Calisto MT} 20 bold")

            # Execute the capture.
            # Get the coordinates of the opposing hole.
            oppos_hol = (abs(self.board.player_turn-1), self.board.hols-final_hol[-1]-1)
            # Add the stones in the final_hol and oppos_hol to the relevant mancala (given by final_hol[0]).
            self.board.mancalas[final_hol[0]] += self.board.board_sides[final_hol[0]][final_hol[1]] + self.board.board_sides[oppos_hol[0]][oppos_hol[1]]
            # Set both holes to 0 to indicate that the stones have been removed.
            self.board.board_sides[oppos_hol[0]][oppos_hol[1]] = 0
            self.board.board_sides[final_hol[0]][final_hol[1]] = 0

            # Highlight the captured holes to alert the user to what is happening.
            self.highlight_hols(None, (final_hol, oppos_hol))
        else: # no capture
            # Remove any capture text from before.
            try:
                self.canvas.itemconfig(self.capture_message, text="")
            except:
                self.capture_message = self.canvas.create_text(self.x_pos(1000), self.y_pos(50), anchor=W, text="", font="{Calisto MT} 20 bold")

        # After self.wait period of time, update the holes. We want to wait so that the user
            # has time to process what is happening!
        self.canvas.after(self.wait, self.update_hols)

    def finalise(self, final_hol: tuple) -> None:
        """
        Find out if the game is over, and then clean up if it is. Otherwise, continue with the next move.
        """
        # Check if the game is over.
        if self.board.is_game_over():
            # Disable all buttons as the game is finished.
            self.disable_buttons()
            # Update all the holes (to 0).
            self.update_hols()
            # Get the player types in a more convenient format.
            player_types = [x.player_type for x in self.board.players]
            # Find out if a human was involved.
            if player_types != [0,0] and (0 in player_types):
                # Computer vs. Human
                # contribute indicates whether or not we are adding to the user's stats.
                contribute = True
            else:
                contribute = False

            # If both mancalas contain the same number of stones, we have a draw.
            if self.board.mancalas[0] == self.board.mancalas[1]:
                # Display this fact to the user.
                self.canvas.itemconfig(self.turn, text="Game Over.  Draw.")
                # If a user was logged in, save the stats to the database.
                if contribute and self.username != "Guest":
                    # Store a draw (index 1).
                    self.DB.update_stats(self.username, [0,1,0])
            else: # there is a definite winner
                # winner stores the 0 or 1, representing the player number.
                winner = 0 if self.board.mancalas[0] > self.board.mancalas[1] else 1
                # The loser is the other player.
                loser = abs(winner-1)
                # Display the Winner and the Loser on the canvas.
                self.canvas.itemconfig(self.turn, text=f"Game Over.  Winner: {self.board.players[winner].player_name}.  Loser: {self.board.players[loser].player_name}.")
                # If a user was logged in, save the stats to the database.
                if contribute and self.username != "Guest":
                    if self.board.players[winner].player_type == 0:
                        # Store a win (index 0).
                        self.DB.update_stats(self.username, [1,0,0])
                    else:
                        # Store a loss (index 2).
                        self.DB.update_stats(self.username, [0,0,1])
        else: # game is not over
            if final_hol != "mancala": 
                # final_hol hollow is not self.board.player_turn's mancala, and it is the opponent's move.
                # Update this.
                self.board.player_turn = abs(self.board.player_turn-1)

            if self.board.players[self.board.player_turn].player_type != 0: # computer's move
                # Disable buttons while computer moves.
                self.disable_buttons()
                # Display in the top-left corner whose turn it is.
                self.show_player_turn()

                # Find the chosen starting hollow.
                move_hol = self.board.players[self.board.player_turn].choose_move(self.board)
                # Find the final_hol given the starting move_hol.
                final_hol = self.board.copy_board().move(move_hol)

                # Highlight the relevant hollows so the user can see what is happening.
                self.highlight_hols(self.board.players[self.board.player_turn].player_type, (move_hol, final_hol))
                # Execute the move after a lag period (so this doesn't happen instantly).
                self.canvas.after(self.move_speed, lambda:self.move(move_hol))
            else: # human's move
                # Enable buttons to allow the user to choose their move.
                self.enable_buttons()
                # Highlight the relevant hollows, passing in 0 as a parameter to indicate this is a human.
                self.highlight_hols(0)
                # Display in the top-left corner whose turn it is.
                self.show_player_turn()
            
            # Check to see if a capture message was displayed (and thus that a capture occurred).
            if self.canvas.itemcget(self.capture_message, "text") != "":
                # Highlight the captured holes to show what is happening.
                self.canvas.after(self.wait, self.update_hols)
            else:
                # If no capture, update holes immediately.
                self.update_hols()

    def highlight_hols(self, player=None, hols=None) -> None:
        """
        Highlight the pertinent hollows.

        player: indicates which TYPE of player it is (i.e., human or computer).
        hols: list of tuples -- start and finish hols OR hols involved in capture.
        """
        def highlight(hol: tuple) -> None:
            """
            Helper function that actually executes the highlighting functionality.
            """
            if hol == "mancala":
                self.mancala_buttons[self.board.player_turn].configure(bg="#FFFE00")
            else: # hollow
                self.hol_buttons[hol[0]][hol[1]].configure(bg="#FFFE00")

        def unhighlight(hol: tuple) -> None:
            if hol == "mancala":
                self.mancala_buttons[self.board.player_turn].configure(bg=self.board.board_col)
            else: # hollow
                self.hol_buttons[hol[0]][hol[1]].configure(bg=self.board.board_col)

        # There are 3 cases to consider here: human/game over ; computer ; capture.
        if player == 0 or self.board.game_over:
            for index in range(2):
                for button in enumerate(self.hol_buttons[index]):
                    if button[1]["state"] != "disabled":
                        move_hol = (self.board.player_turn, button[0])
                        final_hol = self.board.copy_board().move(move_hol)
                        button[1].bind("<Enter>", lambda event, hol=final_hol:highlight(hol))
                        button[1].bind("<Leave>", lambda event, hol=final_hol:unhighlight(hol))
                    else: # buttons are disabled
                        button[1].unbind("<Enter>")
                        button[1].unbind("<Leave>")
        elif player in (1,2,3): # player is computer
            move_hol, final_hol = hols
            final_hol = self.board.copy_board().move(move_hol)

            self.canvas.after(0, lambda:highlight(move_hol))
            self.canvas.after(self.move_speed//2, lambda:unhighlight(move_hol))
            self.canvas.after(self.move_speed//2, lambda:highlight(final_hol))
            self.canvas.after(self.move_speed, lambda:unhighlight(final_hol))
        else: # capture
            final_hol, oppos_hol = hols

            # Highlight the 2 holes involved in the capture.
            highlight(final_hol)
            highlight(oppos_hol)

            self.canvas.after(self.wait, lambda:unhighlight(final_hol))
            self.canvas.after(self.wait, lambda:unhighlight(oppos_hol))

    def move(self, hol: tuple, human=False) -> None:
        """
        Make the move.
        """
        final_hol = self.board.move(hol, True)

        self.update_hols()
        self.highlight_hols(0)

        # After the move...
        # Check for captures.
        self.canvas.after(0, lambda:self.capture(final_hol))
        # Check if game is over.
        self.canvas.after(self.wait+400, lambda:self.finalise(final_hol))

    def undo_move(self) -> None:
        """
        Undo move functionality. Note that the undo_button is sometimes disabled, in which case this method cannot be accessed.
        """
        # Undo the move.
        self.board.undo_move()
        self.update_hols()

        self.undo_button["state"] = "disabled"

        self.enable_buttons()
        self.highlight_hols(0)

    def update_hols(self) -> None:
        """
        Update the hollows that are displayed in the window.
        """
        # Display whose turn it is in top-left corner.
        self.show_player_turn()

        ############ UPDATE HOLLOWS ############

        for side in (0, 1): # 0 is bottom, 1 is top row
            # Make a deep copy to avoid aliasing.
            side_hols = copy.deepcopy(self.board.board_sides[side])

            for h in range(self.board.hols):
                # Update the number of stones in the hole.
                self.hol_buttons[side][h]["text"] = f"{side_hols[h]}"
                # Update the color of the hole.
                self.hol_buttons[side][h].configure(bg=self.board.board_col)

        ########################################

        ############ UPDATE MANCALAS ###########

        for side in (1, 0):
            # Update the number of stones in the mancala.
            self.mancala_buttons[side]["text"] = f"{self.board.mancalas[side]}"
            # Update the color of the mancala.
            self.mancala_buttons[side].configure(bg=self.board.board_col)

        ########################################

    def show_player_turn(self, first=False) -> None:
        """
        Display which player's turn it is in the top-left corner.
        """
        player = self.board.players[self.board.player_turn]
        if first:
            self.turn = self.canvas.create_text(self.x_pos(30), self.y_pos(30), anchor=NW, text=f"{player.player_name}'s turn", font="{Calisto MT} 24 bold")
        else:
            self.canvas.itemconfig(self.turn, text=f"{player.player_name}'s turn")

    def disable_buttons(self) -> None:
        """
        Disable all the buttons.
        """
        for hol in self.hol_buttons[0] + self.hol_buttons[1]:
            hol["state"] = "disabled"
        self.undo_button["state"] = "disabled"

    def enable_buttons(self) -> None:
        """
        Enable the pertinent buttons for the player whose turn it is.
        """
        # Disable opponent's buttons.
        for hol in self.hol_buttons[abs(self.board.player_turn-1)]:
            hol["state"] = "disabled"

        # Iterate over self.player_turn's buttons.
        for h in range(self.board.hols):
            # If the hollow is empty, then disable the button as we can't choose that hollow.
            if self.board.board_sides[self.board.player_turn][h] == 0:
                self.hol_buttons[self.board.player_turn][h]["state"] = "disabled"                    
            else: # ...otherwise, enable it
                self.hol_buttons[self.board.player_turn][h]["state"] = "normal"

        # If there are previous states / stack is not empty...
        if len(self.board.board_states) != 0:
            self.undo_button["state"] = "normal"

    def game_options(self) -> None:
        """
        Display Game Options to the user user.
        """
        self.base_window("Game Options", "Please select an option:")

        button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=lambda:self.host_game(False))
        button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

        ##################################################################
        ###################### GAME MENU OPTIONS #########################
        ##################################################################

        # 1. Configure gameboard
        button1 = Button(self.root, text="1", font="{Calisto MT} 28 bold", width=3, height=1, command=lambda:self.config_menu("game options"))
        button1.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC), anchor=W, text="Configure Gameboard", font="{Calisto MT} 28 bold")

        # 2. Computer move speed
        button2 = Button(self.root, text="2", font="{Calisto MT} 28 bold", width=3, height=1, command=self.change_move_speed)
        button2.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+self.BUTTON_SPACING), anchor=W, text="Move Speed", font="{Calisto MT} 28 bold")

        # 3. Save state of game and return to main menu
        button3 = Button(self.root, text="3", font="{Calisto MT} 28 bold", width=3, height=1, command=self.save_game)
        button3.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+2*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+2*self.BUTTON_SPACING), anchor=W, text="Save Game", font="{Calisto MT} 28 bold")

        # 4. View rules
        button4 = Button(self.root, text="4", font="{Calisto MT} 28 bold", width=3, height=1, command=lambda:self.rules("game options"))
        button4.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+3*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+3*self.BUTTON_SPACING), anchor=W, text="View Rules", font="{Calisto MT} 28 bold")

        # 5. Quit game
        button5 = Button(self.root, text="5", font="{Calisto MT} 28 bold", width=3, height=1, command=self.quit_game)
        button5.place(x=self.x_pos(180), y=self.y_pos(self.FIRST_LOC+4*self.BUTTON_SPACING), anchor=W)
        self.canvas.create_text(self.x_pos(300), self.y_pos(self.FIRST_LOC+4*self.BUTTON_SPACING), anchor=W, text="Quit Game", font="{Calisto MT} 28 bold")

        ##################################################################

    def change_move_speed(self) -> None:
        """
        Change the speed with which the computer moves.
        """
        self.base_window()

        # "Back" button to Game Options.
        button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.game_options)
        button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

        # Get the new move speed from the user.
        entry = Entry(self.root, font="{Calisto MT} 17")
        entry.pack()
        self.canvas.create_window(self.x_pos(800), self.y_pos(350), anchor=W, window=entry, width=400, height=80)
        self.canvas.create_text(self.x_pos(440), self.y_pos(350), text="Enter move speed (milliseconds):", font="{Calisto MT} 28 bold")

        def change_speed(return_key=None):
            """
            Helper function to change the move speed.
            """
            # Get the new move speed from the user.
            move_speed = entry.get()

            # Check that the move speed is valid.
            if move_speed.isdigit():
                self.move_speed = int(move_speed)
            else:
                self.error_message("Invalid move speed.")
            
            # Jump to Game Options menu.
            self.game_options()

        # When the Return key is clicked, change_speed is called.
        self.root.bind("<Return>", change_speed)

    def read_game(self, game_name: str) -> list:
        """
        Retrieves the game details of game_name, and removes all details associated with game_name in the .txt file and .accdb file.

        Returns the game in code representation.
        """
        # Find the game details corresponding to game_name.
        with open(self.SAVED_GAMES, "r") as file:
            for line in file.readlines():
                line.strip("\n")
                # Lines are of the format game_name : details.
                game = line.split(" : ")
                if game[0] == game_name:
                    game[1] = game[1].split(" ; ")
                    game[1] = [x.split(" + ") for x in game[1]]
                    for x in range(len(game[1])):
                        for y in range(len(game[1][x])):
                            # Convert str format to code representations.
                            try:
                                game[1][x][y] = eval(game[1][x][y])
                            except NameError:
                                continue
                    # Break here as we have found the required game.
                    break
                else:
                    continue
        
        # Remove the game from the file.
        with open(self.SAVED_GAMES, "r") as file:
            # Get all games as a list.
            games = [x.strip("\n") for x in file.readlines()]
            # Get only the names of each of the games as a list.
            game_names = [x.split(" : ")[0] for x in games]
            # Remove all data associated with game_name from the games list.
            loc = game_names.index(game_name)
            games.pop(loc)
        
        # Re-write games to the file without the game_name that was read (and subsequently removed).
        with open(self.SAVED_GAMES, "w") as file:
            for line in games:
                file.write(line + "\n")
        
        return game

    def write_game(self, game_name) -> None:
        """
        Append a game to the stored games.
        """
        with open(self.SAVED_GAMES, "a") as file:
            # Concatenate the details together using "+" as a delimiter.
            board_details = f"{self.board.board_sides} + {self.board.mancalas} + {self.board.player_turn}"
            player_details = f"{self.board.players[0].player_num} + {self.board.players[0].player_type} + {self.board.players[0].player_name} + {self.board.players[1].player_num} + {self.board.players[1].player_type} + {self.board.players[1].player_name}"

            # Concatenate the board_details and player_details together using ";" as a delimiter.
            details = " ; ".join([board_details, player_details])

            # Write the details to the file.
            file.write(game_name + " : " + details + "\n")

    def save_game(self) -> None:
        """
        This allows the user to resume a previously saved game.
        """
        self.base_window()

        # "Back" button to Game Options.
        button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.game_options)
        button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

        # Get the name of the game to be saved from the user.
        entry = Entry(self.root, font="{Calisto MT} 17")
        entry.pack()
        self.canvas.create_window(self.x_pos(800), self.y_pos(350), anchor=W, window=entry, width=400, height=80)
        self.canvas.create_text(self.x_pos(440), self.y_pos(350), text="Enter game name:", font="{Calisto MT} 28 bold")

        def save(return_key=None) -> None:
            """
            Helper function that calls methods to store the game in the database and the file.
            """
            game_name = entry.get()

            # Each game associated with a given user must have a unique name.
            if game_name not in self.DB.retrieve_games(self.username):
                # Store the game in the database and the text file.
                self.DB.store_game(self.username, game_name)
                self.write_game(game_name)

                # Jump to Game Options.
                self.game_options()
            else:
                self.error_message("Game name already taken. Please choose a unique name.")

        self.root.bind("<Return>", save)

    def resume_game(self) -> None:
        """
        Retrieve the relevant game_name corresponding to the user.
        """
        self.base_window()

        # "Back" button to Main Menu.
        button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.main_menu)
        button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

        # Get the name of the game to resume.
        entry = Entry(self.root, font="{Calisto MT} 17")
        entry.pack()
        self.canvas.create_window(self.x_pos(800), self.y_pos(350), anchor=W, window=entry, width=400, height=80)
        self.canvas.create_text(self.x_pos(440), self.y_pos(350), text="Enter game name:", font="{Calisto MT} 28 bold")

        def resume(return_key=None):
            game_name = entry.get()

            user_games = self.DB.retrieve_games(self.username)
            found = False
            for g in user_games:
                if g == game_name:
                    # Mark that we have found the game.
                    found = True

                    game_details = self.read_game(game_name)[1]

                    # Remove the game as it has now been resumed.
                    self.DB.delete_game(self.username, game_name)

                    # Assign game_details[0] to the board variables.
                    self.board.board_sides, self.board.mancalas, self.board.player_turn = game_details[0]

                    # Assign the game_details[1] to the player variables.
                    player1 = Player(game_details[1][0], game_details[1][1], game_details[1][2])
                    player2 = Player(game_details[1][3], game_details[1][4], game_details[1][5])

                    self.board.players = (player1, player2)
                    
                    # Resume the game, and pass in False for the new_game parameter.
                    self.host_game(False)

                    # Break, as we have found the game.
                    break

            # Game not found under the given username in the database.
            if not found:
                self.error_message("Game name not found under your username.")

        self.root.bind("<Return>", resume)

    def quit_game(self) -> None:
        """
        Quit the game. This is an automatic forfeit. No points are gained or lost.
        """
        self.base_window()

        self.canvas.create_text(self.x_pos(80), self.y_pos(300), anchor=NW, text="Returning to Main Menu...", font="{Calisto MT} 28 bold")

        self.canvas.after(self.wait, self.main_menu)

    def rules(self, source: str) -> None:
        """
        Display the rules of Mancala.
        """
        self.base_window("Rules")

        self.canvas.create_text(self.x_pos(88), self.y_pos(150), anchor=NW, text="-- At each turn, all the pieces in the selected hollow must be picked up. One of these is placed in each of the following hollows, working anti-clockwise, until there are no pieces left.\n-- If a player runs into their own Mancala, place a piece in it.\n-- If a player runs into their opponent’s Mancala, skip it out.\n-- If a player happens to pick a hollow with so many pieces that more than one lap of the board is completed, then they should skip the originating hollow on each subsequent lap. The originating hollow should always remain empty at the end of each turn.\n-- If the last piece a player drops is in their own Mancala, then they take another turn.\n-- If the last piece a player drops is in an empty hollow on their side of the board, they can ‘capture’ the pieces in both this hollow and the one directly opposite.\n-- The game is ended if either:\n\t-- a player has more than half the total number of pieces in their Mancala, or\n\t-- a player is not able to play since all of the hollows on their side are empty.\n-- The game is drawn if both players finish with an equal number of pieces in their Mancalas.", font="{Calisto MT} 18 bold", width=self.x_pos(1400))

        # Determine where "Back" button will lead.
        if source == "main menu":
            button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.main_menu)
            button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)
        elif source == "game options":
            button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.game_options)
            button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

    def config_menu(self, source: str) -> None:
        """
        Allow user to set their preferences.
        """
        self.base_window("Configuration Menu", "Please update only the features you would like to. Press 'Enter' when done.")

        ####################################################################
        ###################### CONFIG MENU OPTIONS #########################
        ####################################################################

        # 1. No. of hollows per player
        entry1 = Entry(self.root, font="{Calisto MT} 17")
        entry1.pack()
        self.canvas.create_window(self.x_pos(780), self.y_pos(self.FIRST_LOC+50), anchor=W, window=entry1, width=400, height=80)
        self.canvas.create_text(self.x_pos(200), self.y_pos(self.FIRST_LOC+50), anchor=W, text="No. of hollows (per player):", font="{Calisto MT} 28 bold")

        # 2. No. of stones per hollow
        entry2 = Entry(self.root, font="{Calisto MT} 17")
        entry2.pack()
        self.canvas.create_window(self.x_pos(780), self.y_pos(self.FIRST_LOC+50+self.ENTRY_SPACING), anchor=W, window=entry2, width=400, height=80)
        self.canvas.create_text(self.x_pos(200), self.y_pos(self.FIRST_LOC+50+self.ENTRY_SPACING), anchor=W, text="No. of stones (per hollow):", font="{Calisto MT} 28 bold")

        # 3. Board color
        entry3 = Entry(self.root, font="{Calisto MT} 17")
        entry3.pack()
        self.canvas.create_window(self.x_pos(780), self.y_pos(self.FIRST_LOC+50+2*self.ENTRY_SPACING), anchor=W, window=entry3, width=400, height=80)
        self.canvas.create_text(self.x_pos(200), self.y_pos(self.FIRST_LOC+50+2*self.ENTRY_SPACING), anchor=W, text="Board color:", font="{Calisto MT} 28 bold")

        # 4. Stones color
        entry4 = Entry(self.root, font="{Calisto MT} 17")
        entry4.pack()
        self.canvas.create_window(self.x_pos(780), self.y_pos(self.FIRST_LOC+50+3*self.ENTRY_SPACING), anchor=W, window=entry4, width=400, height=80)
        self.canvas.create_text(self.x_pos(200), self.y_pos(self.FIRST_LOC+50+3*self.ENTRY_SPACING), anchor=W, text="Stones color:", font="{Calisto MT} 28 bold")

        ####################################################################

        # If the user is in the middle of a game, we can't change the dimensions of the board.
        # If we came from Game Options (rather than Main Menu), then we must be in the middle of a game.
        if source == "game options":
            # Disable the top 2 entries (these change the board dimensions).
            entry1.config(state="disabled")
            entry2.config(state="disabled")
            # "Back" button to Game Options.
            button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.game_options)
            button.place(x=self.x_pos(1500), y=self.y_pos(800), anchor=SE)
        elif source == "main menu":
            # The top 2 entries are now valid (as we are not in the middle of a game).
            entry1.config(state="normal")
            entry2.config(state="normal")
            # "Back" button to Main Menu.
            button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.main_menu)
            button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

        def change(return_key=None):
            """
            Helper function to make changes as given by the user in the entry boxes.
            """
            # Get the requests.
            hollows = entry1.get() # no. of hollows
            stones = entry2.get() # no. of stones
            board_col = entry3.get() # board color
            stones_col = entry4.get() # stones color

            # Append each new value for hollows, stones, board_col, and stones_col.
                # This will be stored in the database under self.username.
            preferences = []

            ########################################################################
            ########################## UPDATE PREFERENCES ##########################
            ########################################################################

            # 1. Hollows
            if hollows != "":
                # Check the entry is valid.
                if hollows.isdigit():
                    hollows = int(hollows)
                    # Assign the new value.
                    self.board.hols = hollows
                    # Keep track of the updated value for eventual storage in the database.
                    preferences.append(hollows)
                else:
                    self.error_message("Invalid number of hollows.")
            else: # no change requested
                preferences.append(self.board.hols)
            
            # 2. Stones
            if stones != "":
                # Check the entry is valid.
                if stones.isdigit():
                    stones = int(stones)
                    # Assign the new value.
                    self.board.stones = stones * self.board.hols * 2
                    # Keep track of the updated value for later storage.
                    preferences.append(stones)
                else:
                    self.error_message("Invalid colour.")
            else:
                preferences.append(self.board.stones//(2*self.board.hols))

            # 3. Board Color
            if board_col != "":
                if board_col in ("blue", "green", "red", "cyan", "magenta", "yellow", "black", "white", "grey"):
                    self.board.board_col = board_col
                    preferences.append(board_col)
                else:
                    self.error_message("Invalid board colour.")
            else:
                preferences.append(self.board.board_col)

            # 4. Stones Color
            if stones_col != "":
                if stones_col in ("blue", "green", "red", "cyan", "magenta", "yellow", "black", "white", "grey"):
                    self.board.stones_col = stones_col
                    preferences.append(stones_col)
                else:
                    self.error_message("Invalid colour.")
            else:
                preferences.append(self.board.stones_col)

            ########################################################################

            # Only store updated preferences for later if the user is logged in.
            if self.username != "Guest":
                self.DB.save_preferences(self.username, preferences)

            # If the source is the Main Menu, then we know we are not in the middle of a game.
                # So, we create an entirely new board with all the new preferences, and assign
                # this to the current board.
            if source == "main menu":
                new_board = Board([self.board.stones//(2*self.board.hols)]*self.board.hols, 0, [self.board.stones//(2*self.board.hols)]*self.board.hols, 0, self.board.player_turn, self.board.board_col, self.board.stones_col)
                self.board = new_board.copy_board()

                # Return to Main Menu.
                self.main_menu()
            elif source == "game options": # only update colors (not dimensions)
                self.board.board_col = preferences[2]
                self.board.stones_col = preferences[3]

                # Return to Game Options.
                self.game_options()

        self.root.bind("<Return>", change)

    def load_preferences(self) -> None:
        """
        This is called when the user first logs in, and is unrelated to resuming games.

        Load preferences from the database. Assign these values to the current board.
        """
        # Load the preferences.
        hollows, stones, board_col, stones_col = self.DB.load_preferences(self.username)

        # Assign these preferences to the current board.
        if hollows != "":
            self.board.hols = int(hollows)
        
        if stones != "":
            self.board.stones = int(stones)*self.board.hols*2

        if board_col != "":
            self.board.board_col = board_col

        if stones_col != "":
            self.board.stones_col = stones_col

        # Construct a new_board with all of these preferences, then re-assign to the current board.
        # The purpose of new_board is to ensure that no features from the previous board are accidentally
            # still here.
        new_board = Board([self.board.stones//(2*self.board.hols)]*self.board.hols, 0, [self.board.stones//(2*self.board.hols)]*self.board.hols, 0, self.board.player_turn, self.board.board_col, self.board.stones_col)
        self.board = new_board.copy_board()

    def leaderboard(self) -> None:
        """
        Display the leaderboard. Convention: order by wins, then draws. Losses are irrelevant.
        """
        self.base_window("Leaderboard")

        self.canvas.create_text(80, 140, anchor=NW, text="Rank" + " "*6 + "Username" + " "*30 + "Wins" + " "*8 + "Draws" + " "*8 + "Losses", font="{Calisto MT} 18 bold")

        leaderboard = []
        for record in self.DB.get_records():
            username = record[1]
            user_stats = eval(record[3])
            leaderboard.append((username, user_stats))

        leaderboard = sorted(leaderboard, key=lambda x: (x[1][0], x[1][1]), reverse=True)
        rank = 1
        for row in enumerate(leaderboard):
            self.canvas.create_text(114, 200+40*row[0], anchor=CENTER, text=f"{rank}", font="{Calisto MT} 18", width=76)
            self.canvas.create_text(190, 200+40*row[0], anchor=W, text=f"{row[1][0]}", font="{Calisto MT} 18", width=369)
            self.canvas.create_text(559, 200+40*row[0], anchor=CENTER, text=f"{row[1][1][0]}", font="{Calisto MT} 18", width=126)
            self.canvas.create_text(685, 200+40*row[0], anchor=CENTER, text=f"{row[1][1][1]}", font="{Calisto MT} 18", width=140)
            self.canvas.create_text(825, 200+40*row[0], anchor=CENTER, text=f"{row[1][1][2]}", font="{Calisto MT} 18", width=400)

            if row[0] != len(leaderboard)-1:
                if row[1][1][:2] != leaderboard[row[0]+1][1][:2]:
                    rank += 1

        # "Back" button to Main Menu.
        button = Button(self.root, text="Back", font="{Calisto MT} 24 bold", command=self.main_menu)
        button.place(x=self.x_pos(1550), y=self.y_pos(844), anchor=SE)

    def quit_program(self, source="") -> None:
        """
        Take user to quitting buffer. Shut down the program.

        source indicates from which window we came from.
        """
        # Remove any existing canvas.
        try:
            self.canvas.destroy()
        except:
            pass

        # Create a new canvas.
        self.canvas = Canvas(self.root, width=self.WINDOW_WIDTH, height=self.WINDOW_HEIGHT)
        self.canvas.pack()

        # Get the image for the quitting buffer.
        img = Image.open(self.mancalaImgPath)
        resized_img = img.resize((self.WINDOW_WIDTH, self.WINDOW_HEIGHT))
        new_image = ImageTk.PhotoImage(resized_img)

        self.canvas.create_image(self.x_pos(800), self.y_pos(444), anchor=CENTER, image=new_image)

        # See if the user is logged in or not.
        if source == "user mode menu":
            # Player is a Guest. Message reads "Thank you for playing Mancala!".
            self.canvas.create_text(self.x_pos(800), self.y_pos(319), anchor=CENTER, text="Thank you for playing", fill="#FFE89F", font="{Calisto MT} 60 bold")
            self.canvas.create_text(self.x_pos(800), self.y_pos(470), anchor=CENTER, text="Mancala!", fill="#FFE89F", font="{Calisto MT} 60 bold")
        else:
            # Player is a logged-in user Message reads "Thank you for playing Mancala [username]!".
            self.canvas.create_text(self.x_pos(800), self.y_pos(319), anchor=CENTER, text="Thank you for playing Mancala", fill="#FFE89F", font="{Calisto MT} 60 bold")
            self.canvas.create_text(self.x_pos(800), self.y_pos(470), anchor=CENTER, text=f"{self.username}!", fill="#FFE89F", font="{Calisto MT} 60 bold")

        # Wait a period of time before shutting the window so the user has time to process the information.
        self.canvas.after(self.wait, self.root.destroy)

        self.root.mainloop()