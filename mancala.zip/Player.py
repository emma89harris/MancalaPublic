import math
import random
import time

class Player:

    # These are the 4 different modes.
    HUMAN = 0 # user input
    EASY = 1 # random choice
    MEDIUM = 2 # minimax w/o alpha-beta pruning to depth 1
    HARD = 3 # minimax w/ alpha-beta pruning to depth 5

    # This hash table is for convenience. It allows us to convert from 0,1 to "A","B" which can
        # be displayed in the terminal. "A","B" are easier for the user to read, but 0,1 are easier
        # to work with.
    indices = {0: "A", 1: "B"}

    def __init__(self, player_num: int, player_type: int, player_name: str) -> None:
        """
        player_num: 0 or 1. These can be thought of as "IDs". They are easier to work with than
            "Emma" and "Alex", for example, as names vary between users.
        player_type: 0 to 3. One of the 4 options: HUMAN, EASY, MEDIUM, HARD.
        player_name: str -- e.g., "Emma".
        """
        # Initialize the attributes.
        self.player_num = player_num
        self.player_type = player_type
        self.player_name = player_name

    def details(self) -> tuple:
        """
        Returns all attributes of the current instance.
        """
        return (self.player_num, self.player_type, self.player_name)

    def choose_move(self, board) -> tuple:
        """
        Choose the move, based on player_type (i.e., HUMAN, EASY, MEDIUM, or HARD).
        """
        # If the player is a human, then take manual input. This is mainly
            # for the Terminal User Interface.
        if self.player_type == self.HUMAN:
            while True:
                # Get the user input.
                move = input("Enter hollow: ").upper()
                # "A" ~ 0 and "B" ~ 1.
                player_num = 0 if move[0] == "A" else 1
                # Get the coordinates (hol) of the hole whose stones we are going to empty.
                    # If the input (move) is invalid, assign -1 to hol.
                hol = (player_num, int(move[1:]) - 1) if move[1:].isdigit() else -1
                # Generate all legal moves, then check if hol is one of them.
                # Also, check that the hole that is selected corresponds to the current player.
                if hol in board.legal_moves() and player_num == board.player_turn:
                    break # move is legal
                print("Invalid move.")
        elif self.player_type == self.EASY:
            # In EASY mode, the computer randomly selects a hole.
            # Keep choosing a hole until we find a non-empty hole.
            while True:
                hol = (board.player_turn, random.choice(list(range(0, board.hols))))
                if board.board_sides[hol[0]][hol[1]] != 0:
                    break
                else:
                    continue
        elif self.player_type == self.MEDIUM:
            # In MEDIUM mode, the computer executes the minimax algorithm to depth 3.
            hol = self.minimax(board, 3)[-1]
        elif self.player_type == self.HARD:
            # In HARD mode, the computer executes the minimax algorithm to depth 5, with the
                # help of alpha-beta pruning.
            # However, if the number of holes is greater than 5, the quality of the evaluation
                # function falls, and so we can't get away with alpha-beta pruning.
            # Thus, we go only to depth 3 (otherwise the algorithm takes too long to run).
            if board.hols <= 5:
                hol = self.alpha_beta(board, 5)[-1]
            else:
                hol = self.minimax(board, 4)[-1]
        else:
            hol = -1

        # If no good/valid move was determined, pick a random one.
        if hol == -1:
            while True:
                hol = (board.player_turn, random.choice(list(range(0, board.hols))))
                if board.board_sides[hol[0]][hol[1]] != 0:
                    break
                else:
                    continue

        return hol

    def minimax(self, board, cutoff: int) -> tuple: # this is called at the root
        """
        Minimax algorithm. Starts by calling the maximizer function as we start at the root.

        cutoff: maximum depth to which algorithm will search.
        """
        # We initialize optimum_hol to -1, as it is yet to be determined.
        # We initialize extra_move to False.
        return self.maximizer(board, cutoff, 0, False, -1)

    def maximizer(self, board, cutoff: int, depth: int, extra_move: bool, optimum_hol: int) -> tuple:
        """
        Maximizer function.
        
        depth: value that increases as computer goes deeper, until it equals cutoff, at which point the algorithm terminates.
        extra_move: determines whether or not computer maximizes again (e.g., due to chaining).
        optimum_hol: the hole that is most ideal (at the moment).
        """
        # Evaluate the board to give a heuristic estimate of the value of the current node.
        board_val = board.evaluation() 

        # Check to see if we have reached the end state yet ("base case").
        if (depth == cutoff and not extra_move) or (board.game_over):
            return board, board_val, optimum_hol

        # Set initial optimum values.
        optimum_board = board
        optimum_board_val = - math.inf

        # If an extra_move exists, then stay at the current depth (need to maximize again).
        # This variable will be passed as a parameter into the next call of maximizer or minimizer.
        next_depth = depth + 1 if not extra_move else depth

        # Iterate through the hollows to find the best move.
        for h in range(board.hols):
            # If the hole is empty, then skip over it. We can't select an empty hole.
            if board.board_sides[board.player_turn][h] == 0:
                continue

            # Find the next board state, supposing we chose hole h.
            next_board, next_extra_move, hol = board.next_board((board.player_turn, h))

            # If the final stone (in reaching the next_board state) landed in a mancala, then the current player 
                # gets another turn, and we want to maximize again.
            # b is the board, v is the evaluation of that board.
            if next_extra_move:
                b, v = self.maximizer(next_board, cutoff, next_depth, next_extra_move, optimum_hol)[:2]
            else:
                b, v = self.minimizer(next_board, cutoff, next_depth, next_extra_move, optimum_hol)[:2]

            # If the evaluation of next_board is greater than any board so far, update the optimum values.
            if v > optimum_board_val:
                # If chaining occurs (i.e., next_extra_move == True), then assign the next state, b.
                optimum_board = next_board if not next_extra_move else b
                optimum_board_val = v
                optimum_hol = hol

        # So far, it appears that returning optimum_hol is not particularly useful. However, we need to keep passing around
            # the optimum_hol, so that when we call the minimax method in the choose_move method, we know which hole to pick.
        return optimum_board, optimum_board_val, optimum_hol

    def minimizer(self, board, cutoff: int, depth: int, extra_move: bool, optimum_hol: int) -> tuple:
        """
        Minimizer function. See documentation and comments in maximizer method for more details.
        """
        board_val = board.evaluation()

        if (depth == cutoff and not extra_move) or (board.game_over):
            return board, board_val, optimum_hol

        optimum_board = board
        optimum_board_val = math.inf

        next_depth = depth+1 if not extra_move else depth

        for h in range(board.hols):
            if board.board_sides[board.player_turn][h] == 0:
                continue

            next_board, next_extra_move, hol = board.next_board((board.player_turn, h))

            if next_extra_move:
                b, v = self.minimizer(next_board, cutoff, next_depth, next_extra_move, optimum_hol)[:2]
            else:
                b, v = self.maximizer(next_board, cutoff, next_depth, next_extra_move, optimum_hol)[:2]

            if v < optimum_board_val:
                optimum_board = next_board if not next_extra_move else b
                optimum_board_val = v
                optimum_hol = hol

        return optimum_board, optimum_board_val, optimum_hol

    def alpha_beta(self, board, cutoff: int) -> tuple:
        """
        Minimax with alpha-beta pruning. This reduces the time to search to a given depth as pruning
            removes unpromising subtrees. This allows us to search deeper.

        Alpha-beta pruning works by stopping when at least one possibility has been found that proves
            the move to be worse than a previously-examined move.
        In particular, alpha stores the minimum score that the maximizing player could achieve, and beta
            stores the maximum score that the minimizing player could achieve. Whenever alpha > beta, there
            is no point searching any further, so we chop off this branch.
        """
        return self.maximizer_AB(board, cutoff, 0, False, -math.inf, math.inf, -1)

    def maximizer_AB(self, board, cutoff: int, depth: int, extra_move: bool, alpha, beta, optimum_hol: int) -> tuple:
        """
        Very similar to the maximizer method earlier, except with additional alpha-beta functionality.

        NOTE: alpha and beta start off with type float (math.inf), but then become ints as soon as they are assigned an
            updated value.
        """
        board_val = board.evaluation()
        if (depth == cutoff and not extra_move) or (board.game_over):
            return board, board_val, optimum_hol

        optimum_board = board
        # This allows us to make a direct comparison between all possible routes from the current node.
        optimum_board_val = -math.inf

        next_depth = depth + 1 if not extra_move else depth

        # We are at the current board state.
        # Iterate through all the possible moves, and see what their board states would look like. This board
            # state is what the minimizing player will face.
        for h in range(0, board.hols):

            if board.board_sides[board.player_turn][h] == 0:
                continue

            # Get the next_board (what the minimizing player will face).
            next_board, next_extra_move, hol = board.next_board((board.player_turn, h))

            # ...although, in case of chaining, next_board is actually what the maximizer faces again!
            if next_extra_move:
                b, v = self.maximizer_AB(next_board, cutoff, next_depth, next_extra_move, alpha, beta, optimum_hol)[:2]
            else:
                b, v = self.minimizer_AB(next_board, cutoff, next_depth, next_extra_move, alpha, beta, optimum_hol)[:2]

            # Out of all possible future board states along the path which starts with choosing hole h, one path gets the best outcome for
                # the maximizing player. The evaluation value of the board state at the end of any given path is stored in v.
            # As we iterate over all the possible choices of h, we calculate this value, v. Each time v is greater than any other
                # previous value of v, we account for this, in the variable optimum_board_val, and store the corresponding board state.
            # optimum_board_val is very similar to alpha. However, we want to store this value before breaking from the loop, so it is
                # helpful to define it separately.
            if v > optimum_board_val:
                optimum_board = next_board if not next_extra_move else b # store the board associated with v
                optimum_board_val = v # update the highest value of v observed as of yet
                optimum_hol = hol # the hole choice that leads to this better value for v

            #####################################################################
            ################ ALPHA-BETA PRUNING FUNCTIONALITY ###################
            #####################################################################

            # optimum_board_val stores the minimum value that can definitely be achieved by the maximizing player
                # (from all possible paths searched so far from the current node).
            # beta stores the maximum score that the minimizing player is assured of at next_depth.
            # Thus, if beta is less than optimum_board_val, then the best the maximizing player can achieve is beta.
                # Hence, if optimum_board_val > beta, there is no point pursuing branches from this node any further.
            if optimum_board_val > beta:
                break

            # Update alpha.
            alpha = max(alpha, v)

            #####################################################################

        return optimum_board, optimum_board_val, optimum_hol

    def minimizer_AB(self, board, cutoff: int, depth: int, extra_move: bool, alpha, beta, optimum_hol: int) -> tuple:
        """
        See documentation and comments in maximizer_AB method above for more details.
        """
        board_val = board.evaluation()

        if (depth == cutoff and not extra_move) or (board.game_over):
            return board, board_val

        optimum_board = board
        optimum_board_val = math.inf

        next_depth = depth + 1 if not extra_move else depth

        for h in range(0, board.hols):
            if board.board_sides[board.player_turn][h] == 0:
                continue

            next_board, next_extra_move, hol = board.next_board((board.player_turn, h))

            if next_extra_move:
                b, v = self.minimizer_AB(next_board, cutoff, next_depth, next_extra_move, alpha, beta, optimum_hol)[:2]
            else:
                b, v = self.maximizer_AB(next_board, cutoff, next_depth, next_extra_move, alpha, beta, optimum_hol)[:2]

            if v < optimum_board_val:
                optimum_board = next_board if not next_extra_move else b
                optimum_board_val = v
                optimum_hol = hol

            #####################################################################
            ################ ALPHA-BETA PRUNING FUNCTIONALITY ###################
            #####################################################################

            if optimum_board_val < alpha:
                break

            beta = min(beta, v)

            #####################################################################

        return optimum_board, optimum_board_val, optimum_hol