import pyodbc

class DB:

    def __init__(self, cursor: pyodbc.Cursor):
        # Pass in the cursor to access the particular database.
        self.cursor = cursor

        # This hash table is for convenient access.
        self.fields = {
            "PlayerID": int,
            "Username": str,
            "Password": str,
            "Stats": str, # format is: (wins, draws, losses) -- this is a tuple
            "Preferences": str
        }

        # This stores the total number of registered users.
        self.users = len(self.get_records())

    def get_single_criterion_sql(self, criteria: tuple, symbol: str) -> str:
        """
        Returns a single SQL criterion - e.g., Password = "ast-mst". This is a helper method for constructing general SQL statements.

        criteria: tuple of format (str, any) <=> (fieldname, fieldvalue) - e.g., ("PlayerID", 4)
        """
        # "criteria" is a single selection -- a tuple with field name and value.
        field, value = criteria[0], criteria[1]
        if self.fields[field] == str:
            statement = str(field) + " " + symbol + " " + "'" + str(value) + "'"
        else:
            statement = str(field) + " " + symbol + " " + str(value)
        
        return statement

    def get_whole_statement_sql(self, criteria_set: dict, decision_word=None) -> str:
        """
        Returns a whole SQL statement - e.g, Username = "eot" AND Password = "ast-mst". This is a helper method for constructing
            general SQL statements.

        criteria_set: dict with objects of the form {str: (str, any)} <=> {fieldname: (symbol, fieldvalue)} - e.g., {"Username": ("=", "eot")}
        decision_word: str - e.g., "AND"; ","
        """
        whole_statement = ""
        # Get a list of all the fields.
        fields = list(criteria_set.keys())

        # Iterate over the fields.
        for field in fields:
            symbol = criteria_set[field][0]
            value = criteria_set[field][1]

            if fields.index(field) < len(criteria_set) - 1:
                whole_statement += self.get_single_criterion_sql((field, value), symbol) + " " + decision_word + " "
            else:
                # This is the last statement, so we don't want to include a decision word.
                whole_statement += self.get_single_criterion_sql((field, value), symbol)

        return whole_statement

    def insert_record(self, record: tuple) -> None:
        """
        Inserts a new record into the database.
        """
        self.cursor.execute(f"""
            INSERT INTO Player (PlayerID, Username, Password, Stats, Preferences)
            VALUES ({record[0]}, '{record[1]}', '{record[2]}', '{record[3]}', '{record[4]}')
        """)

    def delete_record(self, username: str) -> None:
        """
        Deletes the whole record corresponding to "username" from the database.
        """
        self.cursor.execute(f"""
            DELETE FROM Player
            WHERE Username = {username}
        """)

    def update_record(self, username: str, changes: dict) -> None:
        """
        Updates the record under "username" with (new) values given by "changes" dict.

        changes: dict with objects of the form {str: any} <=> {fieldname: newvalue} - e.g., {"Password": "ast-mst"}
        """
        # Make the changes.
        for field in changes:
            value = changes[field]
            changes[field] = ("=", value)

        # Get the statement that will come after the "SET" command in SQL.
        set_statement = self.get_whole_statement_sql(changes, ",")

        self.cursor.execute(f"""
            UPDATE Player
            SET {set_statement}
            WHERE Username = '{username}'
        """)

    def get_records(self, criteria=None, decision_word=None) -> list[tuple]:
        """
        Returns all records with their field values (according to the given parameters) in a table format.

        criteria: dictionary of fields with corresponding values {str: tuple} <=> {fieldname: value} - e.g., {"Username": ("<>", val)}. It has default value of None, in which case it returns everything.
        decision_word: see description of get_whole_statement_sql method
        """
        if criteria:
            statement = self.get_whole_statement_sql(criteria, decision_word)
            self.cursor.execute(f"""
                SELECT *
                FROM Player
                WHERE {statement}
            """)
        else: # default is to return everything
            self.cursor.execute(f"""
                SELECT *
                FROM Player
            """)
        return self.cursor.fetchall() # this is a list of tuples

    def get_usernames(self) -> list[str]:
        """
        Return all the usernames in the database.
        """
        return [r[1] for r in self.get_records()]

    def get_password(self, username: str) -> str:
        """
        Return the (hashed) password that corresponds to "username".
        """
        user_record = self.get_records({"Username": ("=", username)})[0]
        return user_record[2]

    def create_user(self, username: str, password: str, stats=[0, 0, 0], preferences="|||") -> None:
        """
        Create an account for a new user.
        """
        # Increment the total number of users.
        self.users += 1

        # Create a new record.
        self.insert_record((self.users, username, password, stats, preferences))

        # Each player must have a unique ID. This is determined by the value of self.users.
        self.cursor.execute(f"""
            INSERT INTO Game (PlayerID)
            VALUES ({self.users})
        """)

    def save_preferences(self, username: str, preferences: str) -> None:
        """
        Save user preferences to the database for later access.
        """
        # Convert str format to list.
        preferences = [str(x) for x in preferences]
        # Join up with "|" character for storage in the database.
        preferences = "|".join(preferences)

        # Update the record with the new information.
        self.update_record(username, {"Preferences": preferences})

    def load_preferences(self, username:str) -> list:
        """
        Load preferences corresponding to "username". Preferences include features such as background color.
        """
        # Retrieve the preferences.
        preferences = self.get_records({"Username": ("=", username)})[0][-1].split("|")

        return preferences

    def get_stats(self, username: str) -> list:
        """
        Retrieve the performance statistics stored under "username". This is the number of games won/drawn/lost.
        """
        return eval(self.get_records({"Username": ("=", username)})[0][-2])

    def update_stats(self, username: str, res: list[bool]) -> None:
        """
        Update the performance statistics stored under "username".

        res: list of bools -- format: [win, draw, loss]
        """
        # Retrieve the current stats under "username".
        stats = self.get_stats(username)

        # Update these stats.
        if res[0] == True:
            stats[0] += 1
        elif res[1] == True:
            stats[1] += 1
        else:
            stats[2] += 2

        # Reassign the updated stats to "username".
        self.update_record(username, {"Stats": stats})

    def delete_game(self, username: str, game_name: str) -> None:
        """
        Delete a game from the database.
        """
        # Retrieve the names of all saved games under "username".
        game_names = self.retrieve_games(username)

        # Remove the game_name in question.
        game_names.remove(game_name)

        # Reassemble the remaining game names.
        game_names = " ; ".join(game_names)

        # Update the field with the new value for game_names.
        self.cursor.execute(f"""
            UPDATE Game
            INNER JOIN Player
            ON Game.PlayerID = Player.PlayerID
            SET Game.SavedGames = '{game_names}'
            WHERE Player.Username = '{username}'
        """)

    def store_game(self, username: str, game_name: str) -> None:
        """
        Store a game (name) in the given database.
        """
        # Retrieve a list of all the game names stored under "username".
        game_names = self.retrieve_games(username)

        # Add the new game_name to this list.
        game_names.append(game_name)

        # Reassemble the games for storage.
        game_names = " ; ".join(game_names)

        # Update the field with new values.
        self.cursor.execute(f"""
            UPDATE Game
            INNER JOIN Player
            ON Game.PlayerID = Player.PlayerID
            SET Game.SavedGames = '{game_names}'
            WHERE Player.Username = '{username}'
        """)

    def retrieve_games(self, username: str) -> list[str]:
        """
        Retrieve all games that have been saved under "username".
        """
        # Use SQL to retrieve the SavedGames data for "username".
        self.cursor.execute(f"""
            SELECT Game.SavedGames
            FROM Game
            INNER JOIN Player
            ON Game.PlayerID = Player.PlayerID
            WHERE Player.Username = '{username}'
        """)

        try:
            # See if there are any saved games.
            game_names = self.cursor.fetchall()[0][0]
            game_names.strip("\n")
            game_names = game_names.split(" ; ")
        except AttributeError:
            # ...otherwise, there are not.
            game_names = []

        return game_names

    def hash(self, s: str) -> int:
        """
        Simple hashing function. Summation of the ASCII values of each of the characters in the password, modulo 100.
        """
        total = 0
        for char in s.lower():
            total += ord(char) # take the ASCII value

        # mod 100
        total %= 100

        return total